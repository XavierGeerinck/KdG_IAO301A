package com.desple.model;

public enum ETicketOrder {
    WEB, HANDELAAR
}
