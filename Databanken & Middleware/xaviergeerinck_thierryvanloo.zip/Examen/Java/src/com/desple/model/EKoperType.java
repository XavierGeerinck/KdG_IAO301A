package com.desple.model;

public enum EKoperType {
    PARTICULIER, BEDRIJF, PERS
}
