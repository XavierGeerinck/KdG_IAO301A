package com.desple.model;

public enum ETicketType {
    NORMAL, VIP, COMBI, PERS
}
