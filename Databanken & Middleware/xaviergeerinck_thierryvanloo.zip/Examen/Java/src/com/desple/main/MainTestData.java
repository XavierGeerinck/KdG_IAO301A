package com.desple.main;

import com.desple.testData.TestData;

/**
 * Created with IntelliJ IDEA.
 * User: Thierry
 * Date: 26/10/13
 * Time: 15:13
 * To change this template use File | Settings | File Templates.
 */
public class MainTestData {

    public static void main(String[] args) {


        TestData test = new TestData("../Java/testData/");

    }


}
