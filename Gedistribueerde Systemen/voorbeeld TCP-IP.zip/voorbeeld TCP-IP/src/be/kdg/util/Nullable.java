/*
 * Gedistribueerde systemen
 * Karel de Grote-Hogeschool
 * 2006-2007
 * Kris Demuynck
 */

package be.kdg.util;

/**
 * This interface can be used to create null-objects
 */
public interface Nullable {
    public boolean isNull();
}
