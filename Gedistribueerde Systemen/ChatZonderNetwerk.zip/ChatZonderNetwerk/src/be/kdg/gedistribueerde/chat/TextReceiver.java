package be.kdg.gedistribueerde.chat;

public interface TextReceiver {
    void receive(String text);
}
