package com.kdg.mvc.model;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by xaviergeerinck on 29/11/13.
 */
public interface UserRepository extends JpaRepository<User, Long> {
}