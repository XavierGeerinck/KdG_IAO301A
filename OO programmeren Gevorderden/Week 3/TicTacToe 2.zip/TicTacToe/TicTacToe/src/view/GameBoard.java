package view;

import view.listener.GameListener;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;

/**
 * This is a Canvas where the game is drawn on.
 * This is also where the game data resides.
 */
public class GameBoard extends Canvas {
    public static final int EMPTY = 0, X_PIECE = 1, O_PIECE = 2;
    private int[][] gameGrid = new int[3][3]; // Game grid
    private boolean xTurn; // Is it X's turn?
    private Random random; // Random generator
    private boolean gameRunning; // Is a game in progress?
    private int gameResult; // Result of game

    /**
     * Creates a new game board.
     */
    public GameBoard() {
        // Set the size and background color
        setPreferredSize(new Dimension(256, 256));
        setBackground(Color.WHITE);
        // Add mouse listener
        addMouseListener(new GameListener(this));
        // Create a new random
        random = new Random();
        // Wipe grid
        wipeGrid();
        // Set game status
        gameRunning = true;
    }

    /**
     * Clears the game board of all pieces.
     * This function also sets a random turn for the next player.
     */
    public void wipeGrid() {
        // Wipes the entire grid
        for (int y = 0; y < 3; y++)
            for (int x = 0; x < 3; x++)
                gameGrid[x][y] = EMPTY;
        // Set player
        if (random.nextInt(100) < 50)
            xTurn = true;
        else
            xTurn = false;
    }

    /**
     * Checks to see if the game is over.
     *
     * @return If the game is over or not. 0 = Not over, 1 = X wins, 2 = O wins, 3 = tie
     */
    public int isGameOver() {
        // Check for a match
        for (int x = 0; x < 3; x++) // Rows
            if (gameGrid[x][0] == gameGrid[x][1] && gameGrid[x][1] == gameGrid[x][2])
                return gameGrid[x][0];
        for (int y = 0; y < 3; y++) // Columns
            if (gameGrid[0][y] == gameGrid[1][y] && gameGrid[1][y] == gameGrid[2][y])
                return gameGrid[0][y];
        // Diagonal 1
        if (gameGrid[0][0] == gameGrid[1][1] && gameGrid[1][1] == gameGrid[2][2])
            return gameGrid[0][0];
        if (gameGrid[2][0] == gameGrid[1][1] && gameGrid[0][2] == gameGrid[1][1])
            return gameGrid[2][0];
        // Check for tie
        for (int y = 0; y < 3; y++)
            for (int x = 0; x < 3; x++)
                if (gameGrid[x][y] == 0)
                    return 0; // Not a tie because there is an empty space
        // The game is a tie
        return 3;
    }

    public void newGame() {
        // New game
        wipeGrid();
        setGameRunning(true);
        repaint();
    }

    public boolean inGameBoard(int xPos, int yPos) {
        return xPos > 50 && yPos > 50 && xPos < 50 + 50 * 3 && yPos < 50 + 50 * 3;
    }

    public void checkWinningGame() {
        setGameResult(isGameOver());
        if (getGameResult() != 0) {
            // Game has ended!
            setGameRunning(false);
        }
    }

    public void doMove(int xPos, int yPos) {
        if (isxTurn()) {
            getGameGrid()[xPos / 50 - 1][yPos / 50 - 1] = X_PIECE;
            setxTurn(false);
        } else {
            getGameGrid()[xPos / 50 - 1][yPos / 50 - 1] = O_PIECE;
            setxTurn(true);
        }
    }

    public boolean isEmptyPlace(int xPos, int yPos) {
        return getGameGrid()[xPos / 50 - 1][yPos / 50 - 1] != EMPTY;
    }

    /**
     * Paints the game board.
     */
    public void paint(Graphics g) {
        // Clear old stuff out
        g.clearRect(0, 0, getWidth(), getHeight());
        // Draw lines
        g.setColor(Color.BLACK);
        for (int y = 1; y < 3; y++)
            g.drawLine(50, y * 50 + 50, 50 + 50 * 3, y * 50 + 50);
        for (int x = 1; x < 3; x++)
            g.drawLine(x * 50 + 50, 50, x * 50 + 50, 50 + 50 * 3);
        // Draw pieces
        for (int y = 0; y < 3; y++) {
            for (int x = 0; x < 3; x++) {
                if (gameGrid[x][y] == X_PIECE) {
                    g.setColor(Color.BLUE);
                    g.drawLine(50 + x * 50, 50 + y * 50, 50 + x * 50 + 50, 50 + y * 50 + 50);
                    g.drawLine(50 + 50 + x * 50, 50 + y * 50, 50 + x * 50, 50 + y * 50 + 50);
                }
                if (gameGrid[x][y] == O_PIECE) {
                    g.setColor(Color.RED);
                    g.drawOval(50 + x * 50, 50 + y * 50, 50, 50);
                }
            }
        }
        // Check for turns
        g.setColor(Color.BLACK);
        if (gameRunning) {
            // Turn message
            if (xTurn)
                g.drawString("It is player X's turn.", 10, 20);
            else
                g.drawString("It is player O's turn.", 10, 20);
        } else {
            // End message
            if (gameResult == X_PIECE)
                g.drawString("Player X won!", 10, 20);
            if (gameResult == O_PIECE)
                g.drawString("Player O won!", 10, 20);
            if (gameResult == 3)
                g.drawString("Tie game!", 10, 20);
            // Prompt message
            g.drawString("Click to start a new game.", 10, 40);
        }
    }

    public int[][] getGameGrid() {
        return gameGrid;
    }

    public void setGameGrid(int[][] gameGrid) {
        this.gameGrid = gameGrid;
    }

    public boolean isxTurn() {
        return xTurn;
    }

    public void setxTurn(boolean xTurn) {
        this.xTurn = xTurn;
    }

    public Random getRandom() {
        return random;
    }

    public void setRandom(Random random) {
        this.random = random;
    }

    public boolean isGameRunning() {
        return gameRunning;
    }

    public void setGameRunning(boolean gameRunning) {
        this.gameRunning = gameRunning;
    }

    public int getGameResult() {
        return gameResult;
    }

    public void setGameResult(int gameResult) {
        this.gameResult = gameResult;
    }
}
