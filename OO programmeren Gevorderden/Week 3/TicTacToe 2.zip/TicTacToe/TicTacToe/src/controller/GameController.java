package controller;

import model.GameModel;
import view.GameBoard;

/**
 * Created by xaviergeerinck on 27/11/13.
 */
public class GameController {
    private GameBoard view;
    private GameModel model;

    public GameController(GameModel model, GameBoard view) {
        this.view = view;
        this.model = model;
    }

    public void doPlayerClick(int xPos, int yPos) {
        if (model.inGameBoard(xPos, yPos)) {
            // Check to see if game is running
            if (!model.isGameRunning()) {
                gameBoard.newGame();
                return;
            }
            // Check for an empty place
            if (model.isEmptyPlace(xPos, yPos))
                return; // Not empty, can't place piece

            // Place a piece for the current turn and then alternate
            model.doMove(xPos, yPos);

            // Check for a winning game
            model.checkWinningGame();

            // Cause an update
            view.repaint();
        }
    }
}
