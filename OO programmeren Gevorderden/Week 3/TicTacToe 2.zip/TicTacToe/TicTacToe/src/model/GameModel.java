package model;

/**
 * Created by xaviergeerinck on 27/11/13.
 */
public class GameModel {
}
