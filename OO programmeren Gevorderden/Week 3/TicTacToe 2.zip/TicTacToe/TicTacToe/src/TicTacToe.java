import controller.GameController;
import model.GameModel;
import view.GameBoard;

import javax.swing.JFrame;

/**
 * Classic Tic Tac Toe example in java.
 * Uses Java GUI
 *
 * @author WolfCoder
 * @author 11-08-2007
 */
public class TicTacToe extends JFrame {

    /**
     * Starts the game of Tic Tac Toe.
     *
     * @param args This is ignored.
     */
    public static void main(String[] args) {
        GameModel gameModel = new GameModel();

        // Create the window for tic tac toe
        TicTacToe ticTacToe = new TicTacToe();
        ticTacToe.setTitle("Tic Tac Toe");
        ticTacToe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Add the game board
        GameBoard gameBoard = new GameBoard();
        ticTacToe.add(gameBoard);
        // Pack and show
        ticTacToe.pack();
        ticTacToe.setLocationRelativeTo(null);
		ticTacToe.setVisible(true);

        GameController gameController = new GameController(gameModel, gameBoard);
	}
}
