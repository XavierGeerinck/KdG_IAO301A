package view;

import controller.GameController;
import model.GameModel;
import view.listener.GameListener;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;

/**
 * This is a Canvas where the game is drawn on.
 * This is also where the game data resides.
 */
public class GameBoard extends Canvas {
    /**
     * Creates a new game board.
     */
    public GameBoard() {
        // Set the size and background color
        setPreferredSize(new Dimension(256, 256));
        setBackground(Color.WHITE);
    }

    /**
     * Paints the game board.
     */
    public void paint(Graphics g, int[][] gameGrid, boolean isGameRunning, boolean isXTurn, int gameResult) {
        // Clear old stuff out
        g.clearRect(0, 0, getWidth(), getHeight());

        drawGrid(g);
        drawPieces(g, gameGrid);

        // Check for turns
        g.setColor(Color.BLACK);
        if (isGameRunning) {
            // Turn message
            if (isXTurn)
                g.drawString("It is player X's turn.", 10, 20);
            else
                g.drawString("It is player O's turn.", 10, 20);
        } else {
            // End message
            if (gameResult == GameModel.X_PIECE)
                g.drawString("Player X won!", 10, 20);
            if (gameResult == GameModel.O_PIECE)
                g.drawString("Player O won!", 10, 20);
            if (gameResult == 3)
                g.drawString("Tie game!", 10, 20);
            // Prompt message
            g.drawString("Click to start a new game.", 10, 40);
        }
    }

    private void drawGrid(Graphics g) {
        // Draw lines
        g.setColor(Color.BLACK);

        for (int y = 1; y < 3; y++)
            g.drawLine(50, y * 50 + 50, 50 + 50 * 3, y * 50 + 50);

        for (int x = 1; x < 3; x++)
            g.drawLine(x * 50 + 50, 50, x * 50 + 50, 50 + 50 * 3);
    }

    private void drawPieces(Graphics g, int[][] gameGrid) {
        // Draw pieces
        for (int y = 0; y < 3; y++) {
            for (int x = 0; x < 3; x++) {
                if (isXPiece(gameGrid, x, y)) {
                    g.setColor(Color.BLUE);
                    g.drawLine(50 + x * 50, 50 + y * 50, 50 + x * 50 + 50, 50 + y * 50 + 50);
                    g.drawLine(50 + 50 + x * 50, 50 + y * 50, 50 + x * 50, 50 + y * 50 + 50);
                }
                if (isOPiece(gameGrid, x, y)) {
                    g.setColor(Color.RED);
                    g.drawOval(50 + x * 50, 50 + y * 50, 50, 50);
                }
            }
        }
    }

    private boolean isXPiece(int[][] gameGrid, int x, int y) {
        return gameGrid[x][y] == GameModel.X_PIECE;
    }

    private boolean isOPiece(int[][] gameGrid, int x, int y) {
        return gameGrid[x][y] == GameModel.O_PIECE;
    }
}
